#!/usr/bin/env bash
set -euo pipefail

echo "Install dependencies placeholder"

